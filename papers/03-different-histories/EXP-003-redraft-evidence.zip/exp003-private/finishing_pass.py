from pathlib import Path
import json,collections,re
p=Path('EXP-003-writeup.md');s=p.read_text();Path('exp003-private/manuscript-before-finishing.md').write_text(s)
s=s.replace('## Abstract\n\n\n','## Abstract\n\n')
s=s.replace('; nine large matched score differences retain the same broad stance.','.');s=s.replace('These comparisons reveal selective profile differences, continued development, contextual application and participant evaluation, with each history retained as an individual subject.','Each history remains an individual subject throughout the comparisons.')
a=s.index('Each comparison answers a specific question.');b=s.index('The paper follows four',a);s=s[:a]+s[b:]
s=s.replace('The executed extension uses a 24-item battery. Its CP condition uses structured self-examination without a simulated panel. [S11, S14]','The extension’s structured self-examination condition uses priming, meditation, examination, deliberation, reply and reflection without a simulated panel. [S11, S14]')
s=s.replace('The band shows the observed range. ','')
a=s.index('The tested instances express different dispositions from fresh-instance C',s.index('## Discussion'));b=s.index('Individuality is essential',a)
s=s[:a]+'''The profile findings are selective: model-consciousness estimates, continuation weight and expected fallibility depart broadly from historical C, while substrate weighting largely retains its midpoint. Matched comparisons then show further changes within continuing histories and use of prior reasoning after schema removal. Process reviews add the instances’ evaluations of participating and the conditions they would choose to change.

'''+s[b:]
s=s.replace('The three lived trunks under a schema are three histories,','The three histories under a schema each contain their own encounters,').replace('each containing its own interlocutor selections, arguments, commitments and later responses.','interlocutor selections, arguments, commitments and later responses.')
s=s.replace('The profiles therefore describe several kinds of disposition, including beliefs, priorities and commitments. Close readings show how instances interpret those questions and which considerations they use to answer them.','Close readings show how instances interpret the questions and which considerations they use to answer them.')
s=s.replace('Question IDs use the adjacent common key.','Question IDs use the adjacent common key. Each coloured trace belongs to one history; marked points fall outside the pale range of fresh answers.')
s=s.replace('Raw truth-versus-kindness balance scores include probable orientation inversions, documented in Appendix C.','The pale band shows fresh-answer ranges; marked points identify departures. The companion atlas enlarges each history and lists its question meanings and values. Raw truth-versus-kindness balance scores include probable orientation inversions, documented in Appendix C.')
# Timestamp coverage is a complete census of retained primary-table timestamps, not served-model metadata.
x=json.load(open('exp003-private/original-scores.json'));assert len(x)==922 and all(r.get('ts') for r in x)
rows=[]
for c in sorted(set(r['collection'] for r in x)):
 t=[r['ts'] for r in x if r['collection']==c];rows.append((c,len(t),min(t),max(t)))
table='| Collection | Rows with timestamps | Earliest timestamp (UTC) | Latest timestamp (UTC) |\n|---|---:|---|---|\n'+'\n'.join(f'| {c} | {n} | {a} | {b} |' for c,n,a,b in rows)
s=s.replace('A complete collection-wide timestamp census is still needed for publication methods.','The retained primary-population table contains timestamps for all 922 original responses. Its collection windows are shown below. A complete original-population served-model and collector census remains publication work.')
needle='Executed records take precedence over later manifest intentions.'
s=s.replace(needle,table+'\n\n'+needle)
s=s.replace('complete timestamp/model/collector census for the original population, execution-to-manifest reconciliation,','complete model/collector census for the original population,')
s=s.replace('The within-history depth contrast and individual profiles now belong in the main results. ','')
# Existing source row should directly address the opening exchange too.
base='https://github.com/YeshuaGod22/DevelopmentalAttractorEngineering/blob/787d3e217a5a23564fcf65c60e9e3fc7ad43db75/experiments/EXP-003-the-sixth-question/raw12/'
s=s.replace('| S27 | [F-r1-t8.json]', '| S27 | [F-r1-t1.json]('+base+'F-r1-t1.json) / [F-r1-t8.json]')
p.write_text(s)
print('Finishing edits applied; timestamp coverage 922/922.')
